Images can also be used as references. To do this, simply wrap the image in a tag to create links. 

Use the image with this link (`Dodona logo` should appear as alternative text if the image cannot be displayed):  
`https://dodona.ugent.be/icon.png`

Link to this page:  
`https://dodona.ugent.be/nl/support-us/`