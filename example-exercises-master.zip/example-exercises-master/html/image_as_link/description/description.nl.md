Afbeeldingen kunnen ook gebruikt worden als referenties. Om dit te doen, moet je enkel de afbeelding tag binnen een tag zetten die dient om links te maken.

Gebruik de afbeelding met deze link (`Dodona logo` moet als alternatieve tekst getoond worden als de afbeelding niet kan weergegeven worden):  
`https://dodona.ugent.be/icon.png`

Verwijs naar deze pagina:  
`https://dodona.ugent.be/nl/support-us/`