Display the orange border at the `<img>` element such as in the illustration below:

![Dodona logo with orange border](./media/screenshot.png)

Set the image to a width of 100 pixels. Make the border width equal to 10 pixels.

Don't use shorthand CSS properties.