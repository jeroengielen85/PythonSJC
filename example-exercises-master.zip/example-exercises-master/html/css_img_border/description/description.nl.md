Toon de oranje rand van het `<img>` element zoals in onderstaande screenshot:

![Dodona logo met oranje rand](./media/screenshot.png)

Stel de breedte van de afbeelding in op 100 pixels. Zorg dat de breedte van de rand gelijk is aan 10 pixels.

Gebruik geen verkorte CSS-eigenschappen.