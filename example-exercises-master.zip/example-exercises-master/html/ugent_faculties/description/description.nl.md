Maak een tabel die lijkt op deze hieronder afgebeeld:

![Tabel met bèta faculteiten van Universiteit Gent](./media/table.png){:height="100%" width="100%"}

De titel van het tabblad moet `Bèta-faculties UGent` zijn. Focus op de tabelstructuur, de lay-out mag je ongewijzigd laten (zonder CSS).