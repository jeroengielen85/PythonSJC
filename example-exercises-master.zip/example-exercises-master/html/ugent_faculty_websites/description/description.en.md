Create an unordered list that looks like the one below:

![List with beta faculties of Ghent University](./media/list.png){:height="100%" width="100%"}

The links are respectively:
```markdown
https://www.ugent.be/we/nl
https://www.ugent.be/ea/nl
https://www.ugent.be/bw/nl
```

Focus on the structure, the lay-out can be as is (without CSS).