Typ de basis HTML-template. Die bevat minstens:
* type declaratie
* head
* body
* title met tekst
* charset
* meta
* taal