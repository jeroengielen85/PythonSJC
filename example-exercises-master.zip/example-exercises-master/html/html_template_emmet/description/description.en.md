Write the basic HTML template. The template contains:
* type declaration
* head
* body
* title with text
* charset
* meta
* language