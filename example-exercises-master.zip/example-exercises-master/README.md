# Example exercise repository

This repository contains some basic example exercises to demonstrate their usage. The exercises are organized based on the judge they use.
