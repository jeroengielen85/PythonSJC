In this exercise, the student has to read the `input`, convert that input to a number, and perform mathematical operations on that number in order to `print` out the result.
