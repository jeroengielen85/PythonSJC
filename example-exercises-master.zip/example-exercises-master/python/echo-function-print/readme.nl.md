_nl:_ Dit is een basisoefening; print wat er aan de functie gegeven werd.

(Deze about informatie wordt getoond in het Nederlands, omdat er een gelokaliseerd readme bestand is `readme.nl.md`)
