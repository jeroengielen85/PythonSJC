_en_: This is a basic exercise; print what was given to the function.

(This about information is shown in English, because there is an English readme file `readme.en.md`)
