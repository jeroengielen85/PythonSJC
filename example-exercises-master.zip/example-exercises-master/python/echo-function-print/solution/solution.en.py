def echo(arg):
    print(arg)
