Schrijf een functie `echo` die steeds **print** wat als parameter meegegeven wordt aan de functie.

![echo cave](media/Echo_Caves.jpg){:height="50%" width="50%"}

### Uitvoer

Hetzelfde wordt geprint wat meegegeven wordt tussen de haakjes van de functie.

### Voorbeeld

{: .callout.callout-info}
> #### Voorbeeldnotatie
> Deze notatie imiteert de doctest notatie, waarbij de invoer voorafgegeaan wordt door `>>> ` en de uitvoer tegen de linkerkantlijn staat.

```python
>>> echo("Hello world!")
"Hello world!"
>>> echo(5)
5
```
