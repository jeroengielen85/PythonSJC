This is an example of how you can reuse exercise about information (in this case because it's the same description, but in markdown instead of HTML).

**Note** that this README won't be shown as exercise about because the localized readme files take precedence.
