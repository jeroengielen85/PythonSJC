This exercise is different to the other echo exercise because the student has to implement a function instead of reading an input.
