Schrijf een script `echo` dat steeds uitprint wat er als argumenten aan de functie wordt doorgegeven.

### voorbeeld

```bash
$ echo 5
5
$ echo "ok"
ok
$ echo arg1 arg2
arg1 arg2
```
