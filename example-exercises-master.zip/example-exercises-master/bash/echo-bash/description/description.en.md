Write a script `echo` that prints the arguments that were passed to it.

### example

```bash
$ echo 5
5
$ echo "ok"
ok
$ echo arg1 arg2
arg1 arg2
```
