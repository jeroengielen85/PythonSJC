Write the value "Verwachte waarde" in the code box.
