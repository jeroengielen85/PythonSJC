Schrijf de waarde "Verwachte waarde" in het invoerveld.
