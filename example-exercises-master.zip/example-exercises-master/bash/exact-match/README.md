This exercises allows a teacher to expect an exact value to be entered by the student.
