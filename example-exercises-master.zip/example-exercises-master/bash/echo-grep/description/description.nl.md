Geef een regex die met alles matcht.
