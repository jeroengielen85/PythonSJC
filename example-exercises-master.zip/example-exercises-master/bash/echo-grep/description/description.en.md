Give a regex that matches everything.
