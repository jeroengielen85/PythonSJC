using System;
using System.Collections.Generic;
using System.Text;

namespace ExampleExercises
{
    class Echo
    {
        public static void Main(string[] args)
        {
            string input = Console.ReadLine();
            Console.WriteLine(input);
        }
    }
}
