Write a class  `ExampleExercises.Echo` with a `Main` function that reads a line and prints it back out.
