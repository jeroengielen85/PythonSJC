Schrijf een klasse `ExampleExercises.Echo` met een `Main` methode die een lijn inleest en die dan weer uitschrijft.
