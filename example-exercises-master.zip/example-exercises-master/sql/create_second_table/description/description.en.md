1. Create a table called `STORES` with the following attributes:
* `NAME`, 20 character variable length string
* `NUMBER`, integer
* `CITY`, 20 character variable length string

2. Add the following data in the table `STORES`:

| NAME           | NUMBER | CITY            |
| -------------- | ------ | --------------- |
| 'headquarters' | 4      | 'new york'      |
| 'midwest'      | 5      | 'chicago'       |
| 'west coast'   | 6      | 'san francisco' |
{: .table}

{:start="3"}
3. Display all columns of `STORES`.
