1. Maak een tabel genaamd `STORES` met volgende kenmerken:
* `NAME`, string met variabele lengte van 20 tekens
* `NUMBER`, integer
* `CITY`, string met variabele lengte van 20 tekens

2. Voeg onderstaande data in de tabel `STORES`:

| NAME           | NUMBER | CITY            |
| -------------- | ------ | --------------- |
| 'headquarters' | 4      | 'new york'      |
| 'midwest'      | 5      | 'chicago'       |
| 'west coast'   | 6      | 'san francisco' |
{: .table}

{:start="3"}
3. Geef alle kolommen weer van `STORES` weer.
