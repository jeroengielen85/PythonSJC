![Database schema](media/database_info_icon.png){:data-large="media/database_schema.png"}{:style="float: right"}

Geef alle **beschikbare** producten met productcode `HW` waarvan de kostprijs minder dan 500 bedraagt. Toon alle kolommen.
