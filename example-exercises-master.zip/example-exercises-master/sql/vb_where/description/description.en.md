![Database schema](media/database_info_icon.png){:data-large="media/database_schema.png"}{:style="float: right"}

List all **available** products with product code `HW` that cost less than 500. Show all columns.
