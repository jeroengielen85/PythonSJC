![Database schema icon markdown](https://dodona.ugent.be/nl/repositories/72/public/database_info_icon.png){:data-large="https://dodona.ugent.be/nl/repositories/72/public/database_schema.png"}{:style="float: right"}

For all products of which there are less than 500 in stock, give their description, their product code and the city and state where this product is produced.
