![Database schema icon markdown](https://dodona.ugent.be/nl/repositories/72/public/database_info_icon.png){:data-large="https://dodona.ugent.be/nl/repositories/72/public/database_schema.png"}{:style="float: right"}

Geef van alle producten waarvan er minder dan 500 in voorraad zijn hun beschrijving, hun productcode en de stad en de staat waar dit product geproduceerd wordt.
