Database is based on a dump of the Apache Derby sample database (which is included in the Netbeans editor) converted to SQLite:
* https://github.com/apache/derby/blob/trunk/LICENSE
* https://db.apache.org/derby/derby_downloads.html