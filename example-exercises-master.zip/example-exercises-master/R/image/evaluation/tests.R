contextWithImage({
    testcase("generatePlot()", {
        testImage(function(env) { env$generatePlot() })
    })
})
