In this exercise, we make our first acquaintance with 
the t-test. The t-test is built in to R as the function 
`t.test`. The goal of this exercise is to perform a t-test 
on the `x` and `y` arrays. The `t.test` function has a lot 
of options of which we are only going to use one. Make 
sure the `t.test` function knows the arrays have equal 
variances when you call it.

Most of the code has already been provided; you only need 
to fill in the right arguments for the `t.test` function.