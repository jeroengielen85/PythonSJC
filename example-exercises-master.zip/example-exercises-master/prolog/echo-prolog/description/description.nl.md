Schrijf een predicaat `echo` dat waar is als het tweede argument unificeert met het eerste argument.

### voorbeeld

```prolog
>> echo(5, 5).
true
>> echo("ok", "niet ok").
false
>> echo(panda, X).
X = panda.
```
