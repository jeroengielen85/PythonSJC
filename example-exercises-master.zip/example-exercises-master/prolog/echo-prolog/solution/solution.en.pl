echo(X, X).
