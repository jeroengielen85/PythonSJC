Write a class `Echo` with a `main` function that reads a line and prints it out again.
