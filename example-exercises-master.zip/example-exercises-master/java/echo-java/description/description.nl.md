Schrijf een klasse `Echo` met een `main`-methode die een lijn inleest en terug uitschrijft.
