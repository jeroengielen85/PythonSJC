echo :: a -> a
echo x = x
