import Input (echo)
echo' = echo :: a -> a
main = return () :: IO ()
