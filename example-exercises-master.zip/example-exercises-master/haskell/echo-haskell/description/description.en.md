Write a function `echo` that returns the argument that was passed to it.

### example

```haskell
>> echo 5 
5
>> echo "ok"
"ok"
```