Schrijf een functie `echo` die steeds teruggeeft wat als argument aan de functie wordt doorgegeven.

### voorbeeld

```haskell
>> echo 5 
5
>> echo "ok"
"ok"
```
