This activity is an example of a content page, this is **NOT** an exercise. Note the `"type": "content"` in the [config.json](./config.json).
