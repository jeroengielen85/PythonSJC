function echo(arg) {
	return arg;
}