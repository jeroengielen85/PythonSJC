Schrijf een functie `echo` die steeds teruggeeft wat als argument aan de functie wordt doorgegeven.

### Voorbeeld

```javascript
>> echo(5);
5
>> echo("ok");
"ok"
```
