Write a function `echo` that returns its argument.

### Example

```javascript
>> echo(5);
5
>> echo("ok");
"ok"
```
